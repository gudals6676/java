import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JButton;

public class Scoreinfo_GUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public Scoreinfo_GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("New label");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(125, 10, 158, 54);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("New label");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(308, 10, 114, 41);
		frame.getContentPane().add(label_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 128, 410, 306);
		frame.getContentPane().add(scrollPane);
		
		JLabel label_2 = new JLabel("SCORE INFO");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("���� ����", Font.PLAIN, 25));
		label_2.setBounds(27, 74, 330, 41);
		frame.getContentPane().add(label_2);
		
		JButton btn = new JButton("\uBCF4\uCDA9 \uC2E0\uCCAD");
		btn.setBounds(308, 89, 88, 23);
		frame.getContentPane().add(btn);
	}

}
