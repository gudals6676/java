package VO;

public class TeacherVO {
	String Tea_Number;
	String tea_id;
	String tea_pw;
	String tea_name;
	String tea_subject;
	
	String Class_Number;
	//String Tea_number;// �ܷ��� _2�� ���� ����
	String class_className;
	String class_branch;
	
	String Stu_Number; // �⺻ Ű�� _���� ����
	String Class_number;
	//String Tea_number;
	String stu_id;
	String stu_pw;
	String stu_name;
	String stu_birthday;
	String stu_address;
	String stu_email;

	String Sco_Number;
	//String Stu_number;
	String sco_date;
	String sco_subject;
	String sco_score;

	String Bd_number;
	//String Stu_number;
	String bd_peoplenumber;
	String bd_content;
	
}
